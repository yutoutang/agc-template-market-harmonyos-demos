# 图片水印组件快速入门

## 目录

- [简介](#简介)
- [约束与限制](#约束与限制)
- [使用](#使用)
- [示例代码](#示例代码)

## 简介

本组件提供了图片添加水印、下载保存相册、历史添加缓存等功能。

<img src="./screenshots/watermark.png" width="300">

本组件工程代码结构如下所示：
```ts
picture_watermark/src/main/ets                    // 图片水印(har)
  |- constants                                    // 模块常量定义   
  |- components                                   // 模块组件
  |- types                                        // 模型定义  
  |- pages                                        // 页面
  |- utils                                        // 模块工具类
  |- viewmodel                                    // 与页面一一对应的vm层
```

## 约束与限制
### 环境
* DevEco Studio版本：DevEco Studio 5.0.5 Release及以上
* HarmonyOS SDK版本：HarmonyOS 5.0.5 Release SDK及以上
* 设备类型：华为手机（包括双折叠和阔折叠）
* 系统版本：HarmonyOS 5.0.5(17)及以上

## 使用

1. 安装组件。

   如果是在DevEco Studio使用插件集成组件，则无需安装组件，请忽略此步骤。

   如果是从生态市场下载组件，请参考以下步骤安装组件。

   a. 解压下载的组件包，将包中所有文件夹拷贝至您工程根目录的XXX目录下。

   b. 在项目根目录build-profile.json5添加picture_watermark模块。

    ```
    // 项目根目录下build-profile.json5填写picture_watermark路径。其中XXX为组件存放的目录名
   "modules": [
      {
      "name": "picture_watermark",
      "srcPath": "./XXX/picture_watermark"
      }
   ]
    ```

   c. 在项目根目录oh-package.json5中添加依赖。
    ```
    // XXX为组件存放的目录名
    "dependencies": {
        "picture_watermark": "file:./XXX/picture_watermark"
    }
    ```
   
## 示例代码
```
@Entry
@ComponentV2
export struct Index {
   @Local pageStack: NavPathStack = new NavPathStack();

   build() {
      Navigation(this.pageStack) {
         Button('跳转').onClick(() => {
            // WaterMarksShow为添加水印路由入口页面名称
            this.pageStack.pushPathByName('WaterMarksShow', null);
         });
      }.hideTitleBar(true);
   }
}
```